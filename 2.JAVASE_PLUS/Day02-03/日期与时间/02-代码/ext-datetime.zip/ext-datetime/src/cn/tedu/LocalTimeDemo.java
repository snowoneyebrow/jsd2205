package cn.tedu;

public class LocalTimeDemo {

    // LocalTime的使用与LocalDate高度相似，请自行练习相关API的使用
    public static void main(String[] args) {
        // TODO-01：使用LocalTime的now()静态方法创建LocalTime对象
        // TODO-02：使用LocalTime的of(int hour, int minute, int second)静态方法创建LocalTime对象
        // TODO-03：使用LocalTime的parse(String)静态方法创建LocalTime对象
        // TODO-04：获取小时：public int getHour()
        // TODO-05：获取分钟：public int getMinute()
        // TODO-06：获取秒钟：public int getSecond()
        // TODO-07：在以上TODO-02使用的of()参数列表的最后添加第4个参数，以表示纳秒时间
        // TODO-08：获取纳秒（使用TODO-02得到的LocalTime来练习）：public int getNano()
        // TODO-09：修改小时，得到新的对象：public LocalTime withHour(int hour)
        // TODO-10：修改分钟，得到新的对象：public LocalTime withMinute(int minute)
        // TODO-11：修改秒钟，得到新的对象：public LocalTime withSecond(int second)
        // TODO-12：修改纳秒，得到新的对象：public LocalTime withNano(int nanoOfSecond)
        // TODO-13：增加小时，得到新的对象：public LocalTime plusHours(long hoursToAdd)
        // TODO-14：减少小时，得到新的对象：public LocalTime minusHours(long hoursToSubtract)
        // TODO-15：增加分钟，得到新的对象：public LocalTime plusMinutes(long minutesToAdd)
        // TODO-16：减少分钟，得到新的对象：public LocalTime minusMinutes(long minutesToSubtract)
        // TODO-17：增加秒钟，得到新的对象：public LocalTime plusSeconds(long secondsToAdd)
        // TODO-18：减少秒钟，得到新的对象：public LocalTime minusSeconds(long secondsToSubtract)
        // TODO-19：增加纳秒，得到新的对象：public LocalTime plusNanos(long nanosToAdd)
        // TODO-20：减少纳秒，得到新的对象：public LocalTime minusNanos(long nanosToSubtract)
        // TODO-21：结合LocalDate对象，得到LocalDateTime对象：public LocalDateTime atDate(LocalDate date)
    }

}
