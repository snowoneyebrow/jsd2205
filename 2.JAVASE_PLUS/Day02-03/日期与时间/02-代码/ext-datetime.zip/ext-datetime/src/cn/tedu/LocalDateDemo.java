package cn.tedu;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;

public class LocalDateDemo {

    public static void main(String[] args) {
        // 获取当前时间对应的LocalDate对象
        // 输出格式为：yyyy-MM-dd，例如：2021-08-16
        LocalDate localDate1 = LocalDate.now();
        System.out.println("获取当前时间对应的LocalDate对象");
        System.out.println(localDate1);
        System.out.println();

        // 获取指定日期对应的LocalDate对象
        // 期望值：2015-3-26
        System.out.println("通过2015, 3, 26这3个数值来创建LocalDate对象");
        LocalDate localDate2 = LocalDate.of(2015, 3, 26);
        System.out.println(localDate2);
        System.out.println();

        // 通过字符串的日期获取对应的LocalDate对象
        // 参考值：2003-07-15
        System.out.println("通过\"2003-07-15\"字符串获取对应的LocalDate对象");
        LocalDate localDate3 = LocalDate.parse("2003-07-15");
        System.out.println(localDate3);
        System.out.println();

        // 获取各详情值的API
        System.out.println("获取localDate1（" + localDate1 + "）的详情值");
        int year = localDate1.getYear();
        System.out.println("getYear() --> " + year);
        int monthValue = localDate1.getMonthValue();
        System.out.println("getMonthValue() --> " + monthValue);
        int dayOfMonth = localDate1.getDayOfMonth();
        System.out.println("getDayOfMonth() --> " + dayOfMonth);
        int dayOfYear = localDate1.getDayOfYear();
        System.out.println("getDayOfYear() --> " + dayOfYear);
        int dayOfWeekValue = localDate1.getDayOfWeek().getValue();
        System.out.println("getDayOfWeek().getValue() --> " + dayOfWeekValue);
        boolean isLeapYear = localDate1.isLeapYear();
        System.out.println("isLeapYear() --> " + isLeapYear);
        int lengthOfMonth = localDate1.lengthOfMonth();
        System.out.println("lengthOfMonth() --> " + lengthOfMonth);
        int lengthOfYear = localDate1.lengthOfYear();
        System.out.println("lengthOfYear() --> " + lengthOfYear);
        System.out.println();

        // 调用with前缀的方法修改某些字段的值
        // 原对象：localDate3（2003-07-15）
        // 期望值：年份改为 2009
        LocalDate result;
        result = localDate3.withYear(2009);
        System.out.println("将localDate3（" + localDate3 + "）的【年份】改为【2009】：" + result);
        // 期望值：月份改为 5
        result = localDate3.withMonth(5);
        System.out.println("将localDate3（" + localDate3 + "）的【月份】改为【5】：" + result);
        // 期望值：当月的第几天 23
        result = localDate3.withDayOfMonth(23);
        System.out.println("将localDate3（" + localDate3 + "）的【当月的第几天】改为【23】：" + result);
        // 期望值：全年的第几天 35
        result = localDate3.withDayOfYear(35);
        System.out.println("将localDate3（" + localDate3 + "）的【全年的第几天】改为【35】：" + result);
        System.out.println();

        // 通过plus和minus前缀的方法增加和减少某些字段的值
        System.out.println("通过plus和minus前缀的方法增加和减少某些字段的值");
        result = localDate3.plusYears(2);
        System.out.println("将localDate3（" + localDate3 + "）的【年份】【增加】【2】：" + result);
        result = localDate3.minusYears(5);
        System.out.println("将localDate3（" + localDate3 + "）的【年份】【减去】【5】：" + result);
        result = localDate3.plusMonths(8);
        System.out.println("将localDate3（" + localDate3 + "）的【月份】【增加】【8】：" + result);
        result = localDate3.minusMonths(9);
        System.out.println("将localDate3（" + localDate3 + "）的【月份】【减去】【9】：" + result);
        System.out.println("关于增加/减去星期、天数的API请自行练习……");
        System.out.println();

        // 通过with()方法得到相关LocalDate对象
        System.out.println("通过with()方法得到相关LocalDate对象");
        result = localDate2.with(TemporalAdjusters.firstDayOfMonth());
        System.out.println("获取localDate2（" + localDate2 + "）的相关【该月的第1天 / firstDayOfMonth】：" + result);
        result = localDate2.with(TemporalAdjusters.lastDayOfMonth());
        System.out.println("获取localDate2（" + localDate2 + "）的相关【该月的最后1天 / lastDayOfMonth】：" + result);
        result = localDate2.with(TemporalAdjusters.firstDayOfNextMonth());
        System.out.println("获取localDate2（" + localDate2 + "）的相关【下个月的第1天 / firstDayOfNextMonth】：" + result);
        result = localDate2.with(TemporalAdjusters.firstDayOfYear());
        System.out.println("获取localDate2（" + localDate2 + "）的相关【该年的第1天 / firstDayOfYear】：" + result);
        result = localDate2.with(TemporalAdjusters.lastDayOfYear());
        System.out.println("获取localDate2（" + localDate2 + "）的相关【该年的最后1天 / lastDayOfYear】：" + result);
        result = localDate2.with(TemporalAdjusters.firstDayOfNextYear());
        System.out.println("获取localDate2（" + localDate2 + "）的相关【下一年的第1天 / firstDayOfNextYear】：" + result);
        System.out.println();

        // 基于当前LocalDate对象创建LocalDateTime对象
        LocalDateTime localDateTime;
        localDateTime = localDate2.atStartOfDay();
        System.out.println("基于localDate2（" + localDate2 + "）使用atStartOfDay()【一天的开始】得到LocalDateTime对象：" + localDateTime);
        localDateTime = localDate2.atTime(9, 43);
        System.out.println("基于localDate2（" + localDate2 + "）atTime(9, 43)得到LocalDateTime对象：" + localDateTime);
        localDateTime = localDate2.atTime(9, 43, 27);
        System.out.println("基于localDate2（" + localDate2 + "）atTime(9, 43, 27)得到LocalDateTime对象：" + localDateTime);
        localDateTime = localDate2.atTime(9, 43, 27, 1234);
        System.out.println("基于localDate2（" + localDate2 + "）atTime(9, 43, 27, 1234)得到LocalDateTime对象：" + localDateTime);
    }

}
