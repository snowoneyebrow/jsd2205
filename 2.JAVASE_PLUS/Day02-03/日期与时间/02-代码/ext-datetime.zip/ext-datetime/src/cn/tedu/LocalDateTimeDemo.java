package cn.tedu;

public class LocalDateTimeDemo {

    // 当掌握了LocalDate和LocalTime的用法后，请自行练习LocalDateTime的使用
    public static void main(String[] args) {
        // TODO-01：使用多种不同的方式获取LocalDateTime对象
        // TODO-02：获取LocalDateTime对象的各字段值
        // TODO-03：重新设置LocalDateTime对象的各字段值
        // TODO-04：对LocalDateTime对象的各字段值进行增加、减去操作
        // TODO-05：通过LocalDateTime对象获取LocalDate和LocalTime对象
        // TODO-06：获取LocalDateTime对象的时间戳
        // 示例：long time = LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

}
