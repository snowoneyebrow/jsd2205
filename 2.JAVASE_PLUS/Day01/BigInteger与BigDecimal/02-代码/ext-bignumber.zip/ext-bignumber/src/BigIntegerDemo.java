import java.math.BigInteger;

public class BigIntegerDemo {

    public static void main(String[] args) {
        String value1 = "7777777777666666666655555555554444444444333333333322222222221111111111";
        String value2 = "1111111111222222222233333333334444444444555555555566666666667777777777";

        BigInteger number1 = new BigInteger(value1);
        BigInteger number2 = new BigInteger(value2);
        BigInteger result;

        // 加法
        result = number1.add(number2);
        System.out.println(result);

        // 减法
        result = number1.subtract(number2);
        System.out.println(result);

        // 乘法
        result = number1.multiply(number2);
        System.out.println(result);

        // 除法
        result = number1.divide(number2);
        System.out.println(result);
        System.out.println();

        // 除并求余
        BigInteger[] result2 = number1.divideAndRemainder(number2);
        System.out.println(result2[0]);
        System.out.println(result2[1]);
    }

}
