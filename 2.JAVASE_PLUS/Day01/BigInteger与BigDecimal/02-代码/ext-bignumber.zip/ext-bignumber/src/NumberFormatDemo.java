import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

public class NumberFormatDemo {

    public static void main(String[] args) {
        // 将被格式化的数
        double value = 93.27;
        BigDecimal number = BigDecimal.valueOf(value);

        // 获取NumberFormat工具的对象
        NumberFormat percentInstance = NumberFormat.getPercentInstance();
        NumberFormat currencyInstance = NumberFormat.getCurrencyInstance(Locale.FRANCE);

        // 执行格式化
        String percentResult = percentInstance.format(number);
        String currencyResult = currencyInstance.format(number);

        // 输出结果
        System.out.println(percentResult);
        System.out.println(currencyResult);
    }

}
